// $(".close").click(function(){
//   console.log("i am clicked!");
// });

document.querySelectorAll(".close")addEventListener("click",function(){
  console.log("Someone clicked")
})
