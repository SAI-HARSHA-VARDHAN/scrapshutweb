$(".close").click(function(){
  console.log("i am clicked!");
});


// document.querySelector(".close").addEventListener("click",function(){
//   console.log("Someone clicked")
// });
